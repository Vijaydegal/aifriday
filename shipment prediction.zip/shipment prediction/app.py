import json
import os
import re
from datetime import datetime, timedelta

import httpx
from dotenv import load_dotenv
from flask import Flask, jsonify, request, send_from_directory
from langchain_openai import ChatOpenAI

load_dotenv(override=True)
os.environ.setdefault("LANGCHAIN_OPENAI_TCP_KEEPALIVE", "0")

app = Flask(__name__, static_folder=".", static_url_path="")

HTTP_TIMEOUT = 12
PUBLIC_CLIENT = httpx.Client(timeout=HTTP_TIMEOUT, verify=False, trust_env=False)
LLM_HTTP_CLIENT = httpx.Client(
    verify=False,
    trust_env=os.getenv("GENAI_TRUST_ENV", "false").lower() == "true",
)


@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    response.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
    return response

MODE_PROFILES = {
    "Road": {"hours": 30, "penalty": 18000, "weather": 56, "traffic": 66, "operations": 44, "carrier": 48},
    "Air": {"hours": 18, "penalty": 38000, "weather": 64, "traffic": 34, "operations": 61, "carrier": 58},
    "Sea": {"hours": 96, "penalty": 28000, "weather": 50, "traffic": 42, "operations": 74, "carrier": 68},
    "Rail": {"hours": 58, "penalty": 16000, "weather": 38, "traffic": 36, "operations": 52, "carrier": 43},
}


def clamp_percent(value):
    return max(0, min(100, round(value)))


def route_seed(origin, destination, mode):
    text = f"{origin}|{destination}|{mode}".lower()
    return sum(ord(character) for character in text)


def geocode(place):
    search_terms = [place]
    city_name = place.split(",", 1)[0].strip()
    if city_name and city_name != place:
        search_terms.append(city_name)

    results = []
    for search_term in search_terms:
        response = PUBLIC_CLIENT.get(
            "https://geocoding-api.open-meteo.com/v1/search",
            params={"name": search_term, "count": 1, "language": "en", "format": "json"},
        )
        response.raise_for_status()
        results = response.json().get("results") or []
        if results:
            break

    if not results:
        raise ValueError(f"Could not geocode {place}")

    result = results[0]
    return {
        "name": result.get("name", place),
        "country": result.get("country", ""),
        "latitude": result["latitude"],
        "longitude": result["longitude"],
    }


def get_weather_report(place_geo):
    response = PUBLIC_CLIENT.get(
        "https://api.open-meteo.com/v1/forecast",
        params={
            "latitude": place_geo["latitude"],
            "longitude": place_geo["longitude"],
            "hourly": "precipitation_probability,wind_speed_10m,temperature_2m",
            "forecast_days": 2,
            "timezone": "auto",
        },
    )
    response.raise_for_status()
    hourly = response.json().get("hourly", {})
    precipitation = hourly.get("precipitation_probability", [])[:12]
    wind = hourly.get("wind_speed_10m", [])[:12]
    temperature = hourly.get("temperature_2m", [])[:12]

    max_precipitation = max(precipitation or [0])
    max_wind = max(wind or [0])
    temperature_spread = (max(temperature or [0]) - min(temperature or [0])) if temperature else 0
    weather_risk = clamp_percent(max_precipitation * 0.65 + max_wind * 0.9 + temperature_spread * 1.5)

    return {
        "place": f"{place_geo['name']}, {place_geo.get('country', '')}".strip().strip(","),
        "summary": f"Max precipitation probability {max_precipitation}%, max wind {round(max_wind, 1)} km/h.",
        "risk": weather_risk,
        "max_precipitation": max_precipitation,
        "max_wind": max_wind,
        "temperature_spread": temperature_spread,
    }


def combine_weather_reports(origin_weather, destination_weather):
    route_weather_risk = clamp_percent(
        origin_weather["risk"] * 0.45
        + destination_weather["risk"] * 0.55
    )
    return {
        "summary": (
            f"Origin weather: {origin_weather['summary']} "
            f"Destination weather: {destination_weather['summary']}"
        ),
        "risk": route_weather_risk,
        "origin": origin_weather,
        "destination": destination_weather,
    }


def get_route_report(origin_geo, destination_geo, mode):
    if mode not in {"Road", "Rail"}:
        return {"summary": f"{mode} route estimated from mode profile.", "risk": MODE_PROFILES[mode]["traffic"], "hours": MODE_PROFILES[mode]["hours"]}

    coordinates = (
        f"{origin_geo['longitude']},{origin_geo['latitude']};"
        f"{destination_geo['longitude']},{destination_geo['latitude']}"
    )
    response = PUBLIC_CLIENT.get(
        f"https://router.project-osrm.org/route/v1/driving/{coordinates}",
        params={"overview": "false"},
    )
    response.raise_for_status()
    routes = response.json().get("routes") or []
    if not routes:
        raise ValueError("No OSRM route returned")

    route = routes[0]
    distance_km = route.get("distance", 0) / 1000
    duration_hours = route.get("duration", 0) / 3600
    average_speed = distance_km / duration_hours if duration_hours else 0
    route_risk = clamp_percent(85 - average_speed + min(distance_km / 40, 25))

    return {
        "summary": f"Route distance {round(distance_km)} km, expected drive time {round(duration_hours, 1)} hours.",
        "risk": route_risk,
        "hours": max(duration_hours, MODE_PROFILES[mode]["hours"]),
        "distance_km": distance_km,
        "duration_hours": duration_hours,
    }


def build_rule_prediction(customer, mode, origin, destination, external_reports=None):
    profile = MODE_PROFILES.get(mode, MODE_PROFILES["Road"])
    seed = route_seed(origin, destination, mode)
    route_complexity = seed % 31
    long_route_boost = 8 if len(origin) + len(destination) > 24 else 0
    coastal_boost = 7 if re.search(r"port|beach|harbor|angeles|miami|seattle|oakland", f"{origin} {destination}", re.I) else 0
    metro_boost = 9 if re.search(r"new york|los angeles|chicago|atlanta|dallas|miami|seattle|phoenix", f"{origin} {destination}", re.I) else 0

    external_reports = external_reports or {}
    weather_report = external_reports.get("weather") or {}
    route_report = external_reports.get("route") or {}

    eta_hours = route_report.get("hours") or (profile["hours"] + route_complexity + long_route_boost)
    eta = datetime.now() + timedelta(hours=eta_hours)

    signals = {
        "weather": clamp_percent(weather_report.get("risk", profile["weather"] + (seed % 17) - 8 + coastal_boost)),
        "traffic": clamp_percent(route_report.get("risk", profile["traffic"] + (seed % 19) - 7 + metro_boost)),
        "operations": clamp_percent(profile["operations"] + route_complexity - 10),
        "carrier": clamp_percent(profile["carrier"] + (seed % 23) - 9),
    }
    risk_score = round(
        signals["weather"] * 0.28
        + signals["traffic"] * 0.25
        + signals["operations"] * 0.27
        + signals["carrier"] * 0.20
    )
    risk_level = "high" if risk_score >= 70 else "medium" if risk_score >= 45 else "low"
    penalty = round(profile["penalty"] + route_complexity * 450 + long_route_boost * 600)

    if risk_level == "high":
        recommendation = f"Prioritize {customer}, alert the consignee, reserve backup {mode.lower()} capacity, and adjust the ETA promise before penalties trigger."
    elif risk_level == "medium":
        recommendation = f"Keep the primary plan active, but pre-clear backup routing and monitor weather, traffic, and carrier status before the next dispatch checkpoint."
    else:
        recommendation = "Continue on the planned schedule. No immediate contingency spend is recommended."

    return {
        "eta": eta.strftime("%b %d, %I:%M %p"),
        "penalty": penalty,
        "signals": signals,
        "riskScore": risk_score,
        "riskLevel": risk_level,
        "recommendation": recommendation,
    }


def get_external_reports(origin, destination, mode):
    reports = {"notes": []}
    try:
        origin_geo = geocode(origin)
        destination_geo = geocode(destination)
        reports["origin"] = origin_geo
        reports["destination"] = destination_geo
        origin_weather = get_weather_report(origin_geo)
        destination_weather = get_weather_report(destination_geo)
        reports["weather"] = combine_weather_reports(origin_weather, destination_weather)
        reports["route"] = get_route_report(origin_geo, destination_geo, mode)
    except Exception as exc:
        reports["notes"].append(f"Live network report unavailable: {exc}")
    return reports


def get_llm():
    api_key = os.getenv("GENAI_API_KEY", "").strip()
    if not api_key:
        return None

    return ChatOpenAI(
        base_url=os.getenv("GENAI_BASE_URL", "https://genailab.tcs.in"),
        model=os.getenv("GENAI_MODEL", "azure/genailab-maas-gpt-4.1"),
        api_key=api_key,
        http_client=LLM_HTTP_CLIENT,
    )


def extract_json(text):
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", text, re.S)
        if not match:
            raise
        return json.loads(match.group(0))


def improve_with_llm(payload, external_reports, rule_prediction):
    llm = get_llm()
    if not llm:
        return rule_prediction, "rule-fallback"

    prompt = f"""
You are a logistics delay prediction agent. Use the shipment input, live reports, and baseline model below.
The live weather report includes origin and destination weather. Use that live weather evidence when setting the weather signal.
If live weather is available, do not rely only on the baseline weather signal.
Return only valid JSON with keys: eta, penalty, signals, riskScore, riskLevel, recommendation.
signals must include weather, traffic, operations, carrier as 0-100 integers.
riskLevel must be low, medium, or high.

Shipment input:
{json.dumps(payload, indent=2)}

Live reports:
{json.dumps(external_reports, indent=2)}

Baseline model:
{json.dumps(rule_prediction, indent=2)}
"""
    try:
        response = llm.invoke(prompt)
        llm_prediction = extract_json(response.content)
        return {**rule_prediction, **llm_prediction}, "llm"
    except Exception as exc:
        fallback = dict(rule_prediction)
        fallback["recommendation"] = f"{rule_prediction['recommendation']} LLM refinement unavailable: {exc}"
        return fallback, "rule-fallback"


def ask_llm_agent(question, shipment):
    llm = get_llm()
    if not llm:
        raise RuntimeError("LiteLLM is not configured. Set GENAI_API_KEY and restart the app.")

    prompt = f"""
You are a concise logistics delay mitigation agent.
Answer the user's question using only the selected shipment context below.
If the user asks for an action, recommend practical next steps for a shipment planner.
Keep the answer under 120 words.

Selected shipment:
{json.dumps(shipment, indent=2)}

User question:
{question}
"""
    response = llm.invoke(prompt)
    return response.content.strip()


def predict_contingency_plan(shipment):
    llm = get_llm()
    if not llm:
        raise RuntimeError("LiteLLM is not configured. Set GENAI_API_KEY and restart the app.")

    prompt = f"""
You are a logistics contingency planning agent.
Predict the recommended contingency plan from the selected shipment's risk signals.
Use the weather, traffic, operations, and carrier signals as the main evidence.
Mention the most important signal drivers and give clear planner actions.
Keep the answer under 90 words and do not return JSON.

Selected shipment:
{json.dumps(shipment, indent=2)}
"""
    response = llm.invoke(prompt)
    return response.content.strip()


@app.route("/")
def index():
    return send_from_directory(".", "index.html")


@app.route("/api/health")
def health():
    return jsonify({"ok": True, "llmConfigured": bool(os.getenv("GENAI_API_KEY"))})


@app.route("/api/ask", methods=["POST"])
def ask_agent():
    payload = request.get_json(force=True)
    question = payload.get("question", "").strip()
    shipment = payload.get("shipment") or {}

    if not question:
        return jsonify({"error": "Ask a question before sending it to the agent."}), 400

    if not shipment:
        return jsonify({"error": "Select a shipment before asking the agent."}), 400

    try:
        answer = ask_llm_agent(question, shipment)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 503

    return jsonify({"answer": answer, "source": "llm"})


@app.route("/api/recommendation", methods=["POST"])
def recommendation():
    payload = request.get_json(force=True)
    shipment = payload.get("shipment") or {}

    if not shipment:
        return jsonify({"error": "Select a shipment before requesting a contingency plan."}), 400

    try:
        plan = predict_contingency_plan(shipment)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 503

    return jsonify({"recommendation": plan, "source": "llm"})


@app.route("/api/predict", methods=["POST"])
def predict():
    payload = request.get_json(force=True)
    customer = payload.get("customer", "").strip()
    mode = payload.get("mode", "Road").strip()
    origin = payload.get("origin", "").strip()
    destination = payload.get("destination", "").strip()

    if not customer or not origin or not destination:
        return jsonify({"error": "Customer, origin, and destination are required."}), 400

    external_reports = get_external_reports(origin, destination, mode)
    rule_prediction = build_rule_prediction(customer, mode, origin, destination, external_reports)
    prediction, source = improve_with_llm(payload, external_reports, rule_prediction)

    return jsonify({
        "id": payload.get("id"),
        "customer": customer,
        "mode": mode,
        "route": f"{origin} to {destination}",
        "eta": prediction["eta"],
        "penalty": prediction["penalty"],
        "signals": prediction["signals"],
        "riskScore": prediction["riskScore"],
        "riskLevel": prediction["riskLevel"],
        "recommendation": prediction["recommendation"],
        "source": source,
        "reports": external_reports,
    })


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "5174")), debug=True)
