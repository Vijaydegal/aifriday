const shipments = [
  {
    id: "SHP-1048",
    customer: "Northwind Retail",
    mode: "Road",
    route: "Dallas, TX to Denver, CO",
    eta: "Today, 18:30",
    penalty: 18500,
    signals: {
      weather: 68,
      traffic: 84,
      operations: 42,
      carrier: 50
    }
  },
  {
    id: "SHP-2190",
    customer: "Apex Medical",
    mode: "Air",
    route: "Chicago, IL to Seattle, WA",
    eta: "Tomorrow, 09:15",
    penalty: 42000,
    signals: {
      weather: 76,
      traffic: 35,
      operations: 71,
      carrier: 62
    }
  },
  {
    id: "SHP-3327",
    customer: "Blue Harbor Foods",
    mode: "Sea",
    route: "Port of LA to Oakland, CA",
    eta: "Jun 28, 14:00",
    penalty: 27600,
    signals: {
      weather: 40,
      traffic: 44,
      operations: 81,
      carrier: 73
    }
  },
  {
    id: "SHP-4481",
    customer: "MetroBuild Supply",
    mode: "Rail",
    route: "Kansas City, MO to Phoenix, AZ",
    eta: "Jun 29, 07:45",
    penalty: 12300,
    signals: {
      weather: 24,
      traffic: 30,
      operations: 36,
      carrier: 28
    }
  },
  {
    id: "SHP-5209",
    customer: "FreshCart Grocery",
    mode: "Road",
    route: "Atlanta, GA to Miami, FL",
    eta: "Tomorrow, 16:20",
    penalty: 31800,
    signals: {
      weather: 82,
      traffic: 77,
      operations: 58,
      carrier: 66
    }
  }
];

const weights = {
  weather: 0.28,
  traffic: 0.25,
  operations: 0.27,
  carrier: 0.20
};

let selectedId = shipments[0].id;
let manualShipmentCount = 1;
let contingencyPlanRequestId = 0;

const shipmentList = document.querySelector("#shipmentList");
const modeFilter = document.querySelector("#modeFilter");
const selectedShipment = document.querySelector("#selectedShipment");
const signalStack = document.querySelector("#signalStack");
const recommendationText = document.querySelector("#recommendationText");
const agentConfidence = document.querySelector("#agentConfidence");
const agentAnswer = document.querySelector("#agentAnswer");
const agentForm = document.querySelector("#agentForm");
const refreshBtn = document.querySelector("#refreshBtn");
const manualShipmentForm = document.querySelector("#manualShipmentForm");
const shipmentTabs = document.querySelectorAll(".shipment-tab");
const shipmentTabPanels = document.querySelectorAll(".shipment-tab-panel");
const navItems = document.querySelectorAll(".nav-item");
const shipmentsPanel = document.querySelector("#shipmentsPanel");
const riskSignalsPanel = document.querySelector("#riskSignalsPanel");
const recommendationBox = document.querySelector(".recommendation-box");

function calculateRisk(shipment) {
  const score = Object.entries(shipment.signals).reduce((total, [signal, value]) => {
    return total + value * weights[signal];
  }, 0);

  return Math.round(score);
}

function getRiskLevel(score) {
  if (score >= 70) return "high";
  if (score >= 45) return "medium";
  return "low";
}

function getRecommendation(shipment) {
  if (shipment.recommendation) {
    return shipment.recommendation;
  }

  const score = calculateRisk(shipment);
  const largestSignal = Object.entries(shipment.signals).sort((a, b) => b[1] - a[1])[0][0];

  if (score >= 70) {
    return `High delay probability detected. Prioritize ${shipment.id}, notify ${shipment.customer}, reserve an alternate ${shipment.mode.toLowerCase()} capacity option, and move the ETA promise window before penalties trigger. The strongest risk signal is ${largestSignal}.`;
  }

  if (score >= 45) {
    return `Moderate delay probability. Keep the original plan active, but pre-clear backup routing and alert the planner team to watch ${largestSignal} conditions for the next update cycle.`;
  }

  return `Low delay probability. Continue monitoring and keep this shipment on the standard schedule. No immediate contingency spend is recommended.`;
}

function getContingencySignature(shipment) {
  return JSON.stringify({
    id: shipment.id,
    eta: shipment.eta,
    penalty: shipment.penalty,
    signals: shipment.signals,
    riskScore: calculateRisk(shipment)
  });
}

async function updateContingencyPlan(shipment) {
  const requestId = ++contingencyPlanRequestId;
  const signature = getContingencySignature(shipment);

  if (shipment.contingencyPlan && shipment.contingencySignature === signature) {
    recommendationText.textContent = shipment.contingencyPlan;
    return;
  }

  recommendationText.textContent = "Predicting contingency plan from current risk signals...";

  try {
    const score = calculateRisk(shipment);
    const result = await requestContingencyPlan({
      ...shipment,
      riskScore: score,
      riskLevel: getRiskLevel(score)
    });

    if (requestId !== contingencyPlanRequestId || selectedId !== shipment.id) {
      return;
    }

    shipment.contingencyPlan = result.recommendation;
    shipment.contingencySignature = signature;
    recommendationText.textContent = result.recommendation;
  } catch (error) {
    if (requestId !== contingencyPlanRequestId || selectedId !== shipment.id) {
      return;
    }

    recommendationText.textContent = `LLM contingency plan unavailable: ${error.message}`;
  }
}

function formatCurrency(value) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0
  }).format(value);
}

function clampPercent(value) {
  return Math.max(0, Math.min(100, Math.round(value)));
}

function createRouteSeed(origin, destination, mode) {
  const text = `${origin}|${destination}|${mode}`.toLowerCase();
  return Array.from(text).reduce((total, character) => total + character.charCodeAt(0), 0);
}

function predictShipmentDetails(origin, destination, mode) {
  const modeProfiles = {
    Road: { hours: 30, penalty: 18000, weather: 56, traffic: 66, operations: 44, carrier: 48 },
    Air: { hours: 18, penalty: 38000, weather: 64, traffic: 34, operations: 61, carrier: 58 },
    Sea: { hours: 96, penalty: 28000, weather: 50, traffic: 42, operations: 74, carrier: 68 },
    Rail: { hours: 58, penalty: 16000, weather: 38, traffic: 36, operations: 52, carrier: 43 }
  };
  const profile = modeProfiles[mode];
  const seed = createRouteSeed(origin, destination, mode);
  const routeComplexity = seed % 31;
  const longRouteBoost = origin.length + destination.length > 24 ? 8 : 0;
  const coastalBoost = /port|beach|harbor|angeles|miami|seattle|oakland/i.test(`${origin} ${destination}`) ? 7 : 0;
  const metroBoost = /new york|los angeles|chicago|atlanta|dallas|miami|seattle|phoenix/i.test(`${origin} ${destination}`) ? 9 : 0;
  const etaHours = profile.hours + routeComplexity + longRouteBoost;
  const etaDate = new Date(Date.now() + etaHours * 60 * 60 * 1000);

  return {
    eta: etaDate.toLocaleString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    }),
    penalty: profile.penalty + routeComplexity * 450 + longRouteBoost * 600,
    signals: {
      weather: clampPercent(profile.weather + (seed % 17) - 8 + coastalBoost),
      traffic: clampPercent(profile.traffic + (seed % 19) - 7 + metroBoost),
      operations: clampPercent(profile.operations + routeComplexity - 10),
      carrier: clampPercent(profile.carrier + (seed % 23) - 9)
    }
  };
}

function getApiBaseUrl() {
  if (window.location.protocol === "file:") {
    return "http://127.0.0.1:5174";
  }

  return "";
}

async function requestAiPrediction(input) {
  const response = await fetch(`${getApiBaseUrl()}/api/predict`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(input)
  });

  if (!response.ok) {
    const message = await response.text();
    throw new Error(message || "Prediction service failed.");
  }

  return response.json();
}

async function requestAgentAnswer(question, shipment) {
  const response = await fetch(`${getApiBaseUrl()}/api/ask`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ question, shipment })
  });

  const result = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(result.error || "Agent service failed.");
  }

  return result;
}

async function requestContingencyPlan(shipment) {
  const response = await fetch(`${getApiBaseUrl()}/api/recommendation`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ shipment })
  });

  const result = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(result.error || "Recommendation service failed.");
  }

  return result;
}

function buildLocalPrediction(input) {
  const prediction = predictShipmentDetails(input.origin, input.destination, input.mode);
  const score = Math.round(
    prediction.signals.weather * weights.weather
    + prediction.signals.traffic * weights.traffic
    + prediction.signals.operations * weights.operations
    + prediction.signals.carrier * weights.carrier
  );
  const level = getRiskLevel(score);

  return {
    id: input.id,
    customer: input.customer,
    mode: input.mode,
    route: `${input.origin} to ${input.destination}`,
    eta: prediction.eta,
    penalty: prediction.penalty,
    signals: prediction.signals,
    riskScore: score,
    riskLevel: level,
    source: "browser-fallback",
    recommendation: getRecommendation({
      id: input.id,
      customer: input.customer,
      mode: input.mode,
      route: `${input.origin} to ${input.destination}`,
      eta: prediction.eta,
      penalty: prediction.penalty,
      signals: prediction.signals
    })
  };
}

async function addManualShipment() {
  const customer = document.querySelector("#manualCustomer").value.trim();
  const mode = document.querySelector("#manualMode").value;
  const origin = document.querySelector("#manualOrigin").value.trim();
  const destination = document.querySelector("#manualDestination").value.trim();
  const id = `MAN-${String(manualShipmentCount).padStart(4, "0")}`;
  const input = { id, customer, mode, origin, destination };
  const submitButton = manualShipmentForm.querySelector("button");

  submitButton.disabled = true;
  submitButton.textContent = "Predicting...";

  let prediction;
  try {
    prediction = await requestAiPrediction(input);
  } catch (error) {
    prediction = buildLocalPrediction(input);
    prediction.recommendation = `${prediction.recommendation} Backend unavailable, so the browser fallback model was used.`;
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = "Add";
  }

  const shipment = {
    id,
    customer: prediction.customer || customer,
    mode: prediction.mode || mode,
    route: prediction.route || `${origin} to ${destination}`,
    eta: prediction.eta,
    penalty: prediction.penalty,
    signals: prediction.signals,
    recommendation: prediction.recommendation,
    source: prediction.source || "unknown"
  };

  manualShipmentCount += 1;
  shipments.unshift(shipment);
  selectedId = shipment.id;

  updateMetrics();
  renderShipments();
  renderAgentPanel();
  switchShipmentTab("list");
  setActiveNav("shipments");
  manualShipmentForm.reset();

  const score = calculateRisk(shipment);
  const level = getRiskLevel(score);
  agentAnswer.textContent = `${shipment.id} was predicted from customer, mode, origin, and destination. Result: ${level} delay risk at ${score}%. Source: ${shipment.source}.`;
}

function setActiveNav(target) {
  navItems.forEach((item) => {
    item.classList.toggle("active", item.dataset.target === target);
  });
}

function switchShipmentTab(tabName) {
  shipmentTabs.forEach((tab) => {
    const isActive = tab.dataset.tab === tabName;
    tab.classList.toggle("active", isActive);
    tab.setAttribute("aria-selected", String(isActive));
  });

  shipmentTabPanels.forEach((panel) => {
    const shouldShowList = tabName === "list" && panel.id === "shipmentListTab";
    const shouldShowManual = tabName === "manual" && panel.id === "manualPredictionTab";
    panel.classList.toggle("active", shouldShowList || shouldShowManual);
  });
}

function focusPanel(panel) {
  document.querySelectorAll(".panel-focus").forEach((item) => {
    item.classList.remove("panel-focus");
  });

  panel.classList.add("panel-focus");
  panel.scrollIntoView({ behavior: "smooth", block: "start" });

  window.setTimeout(() => {
    panel.classList.remove("panel-focus");
  }, 1800);
}

function handleNavigation(target) {
  setActiveNav(target);

  if (target === "dashboard") {
    document.querySelector(".topbar").scrollIntoView({ behavior: "smooth", block: "start" });
    return;
  }

  if (target === "shipments") {
    modeFilter.value = "all";
    switchShipmentTab("manual");
    renderShipments();
    focusPanel(shipmentsPanel);
    return;
  }

  if (target === "riskSignals") {
    focusPanel(riskSignalsPanel);
    return;
  }

  if (target === "plans") {
    focusPanel(riskSignalsPanel);
    recommendationBox.classList.add("panel-focus");
    window.setTimeout(() => {
      recommendationBox.classList.remove("panel-focus");
    }, 1800);
  }
}

function updateMetrics() {
  if (shipments.length === 0) {
    document.querySelector("#shipmentCount").textContent = "0";
    document.querySelector("#highRiskCount").textContent = "0";
    document.querySelector("#averageRisk").textContent = "0%";
    document.querySelector("#costExposure").textContent = formatCurrency(0);
    return;
  }

  const risks = shipments.map(calculateRisk);
  const highRiskShipments = shipments.filter((shipment) => calculateRisk(shipment) >= 70);
  const averageRisk = Math.round(risks.reduce((total, risk) => total + risk, 0) / risks.length);
  const costExposure = highRiskShipments.reduce((total, shipment) => total + shipment.penalty, 0);

  document.querySelector("#shipmentCount").textContent = shipments.length;
  document.querySelector("#highRiskCount").textContent = highRiskShipments.length;
  document.querySelector("#averageRisk").textContent = `${averageRisk}%`;
  document.querySelector("#costExposure").textContent = formatCurrency(costExposure);
}

function renderShipments() {
  if (!shipmentList) return;

  const filterValue = modeFilter.value;
  const visibleShipments = filterValue === "all"
    ? shipments
    : shipments.filter((shipment) => shipment.mode === filterValue);

  if (visibleShipments.length === 0) {
    shipmentList.innerHTML = `<div class="empty-state">No shipments found for this view.</div>`;
    return;
  }

  shipmentList.innerHTML = visibleShipments.map((shipment) => {
    const score = calculateRisk(shipment);
    const level = getRiskLevel(score);

    return `
      <div class="shipment-card ${shipment.id === selectedId ? "active" : ""}" data-id="${shipment.id}">
        <div>
          <div class="shipment-title">
            <strong>${shipment.id}</strong>
            <span class="tag">${shipment.mode}</span>
            <span class="risk-pill ${level}">${level} risk</span>
          </div>
          <div class="route-line">${shipment.route}</div>
          <div class="shipment-meta">${shipment.customer} - ETA ${shipment.eta}</div>
        </div>
        <div class="shipment-actions">
          <div class="risk-score">${score}%</div>
          <button class="delete-shipment" type="button" data-id="${shipment.id}" aria-label="Delete ${shipment.id}">Delete</button>
        </div>
      </div>
    `;
  }).join("");

  document.querySelectorAll(".shipment-card").forEach((card) => {
    card.addEventListener("click", () => {
      selectedId = card.dataset.id;
      renderShipments();
      renderAgentPanel();
    });
  });

  document.querySelectorAll(".delete-shipment").forEach((button) => {
    button.addEventListener("click", (event) => {
      event.stopPropagation();
      deleteShipment(button.dataset.id);
    });
  });
}

function deleteShipment(id) {
  const shipmentIndex = shipments.findIndex((shipment) => shipment.id === id);
  if (shipmentIndex === -1) return;

  shipments.splice(shipmentIndex, 1);

  if (selectedId === id) {
    selectedId = shipments[0]?.id || "";
  }

  updateMetrics();
  renderShipments();

  if (shipments.length > 0) {
    renderAgentPanel();
    agentAnswer.textContent = `${id} was deleted from the shipment list.`;
  } else {
    selectedShipment.textContent = "No shipments available. Add a manual prediction to continue.";
    signalStack.innerHTML = "";
    recommendationText.textContent = "Add a shipment to generate an AI recommendation.";
    agentConfidence.textContent = "Ready";
    agentConfidence.className = "confidence";
    agentAnswer.textContent = `${id} was deleted. No shipments remain.`;
  }
}

function renderAgentPanel() {
  const shipment = shipments.find((item) => item.id === selectedId);
  if (!shipment) {
    selectedShipment.textContent = "No shipments available. Add a manual prediction to continue.";
    signalStack.innerHTML = "";
    recommendationText.textContent = "Add a shipment to generate an AI recommendation.";
    agentConfidence.textContent = "Ready";
    agentConfidence.className = "confidence";
    return;
  }

  const score = calculateRisk(shipment);
  const level = getRiskLevel(score);

  selectedShipment.innerHTML = `
    <strong>${shipment.id} - ${shipment.customer}</strong>
    <p>${shipment.route}</p>
    <p>Mode: ${shipment.mode} - ETA: ${shipment.eta} - Penalty exposure: ${formatCurrency(shipment.penalty)}</p>
  `;

  signalStack.innerHTML = Object.entries(shipment.signals).map(([name, value]) => `
    <div class="signal">
      <div class="signal-top">
        <span>${name[0].toUpperCase() + name.slice(1)} signal</span>
        <span>${value}%</span>
      </div>
      <div class="signal-bar">
        <div class="signal-fill" style="width: ${value}%"></div>
      </div>
    </div>
  `).join("");

  updateContingencyPlan(shipment);
  agentConfidence.textContent = `${level.toUpperCase()} - ${score}% confidence`;
  agentConfidence.className = `confidence risk-pill ${level}`;
}

async function askAgent(question) {
  const shipment = shipments.find((item) => item.id === selectedId);
  if (!shipment) {
    agentAnswer.textContent = "No shipment is selected. Add a manual prediction first, then ask the agent for a recommendation.";
    return;
  }

  if (!question.trim()) {
    agentAnswer.textContent = "Ask about penalties, routing, weather, traffic, or the next recommended action.";
    return;
  }

  const submitButton = agentForm.querySelector("button");
  submitButton.disabled = true;
  submitButton.textContent = "Asking...";
  agentAnswer.textContent = "Contacting the agent...";

  try {
    const result = await requestAgentAnswer(question, shipment);
    agentAnswer.textContent = result.answer;
  } catch (error) {
    agentAnswer.textContent = `Agent unavailable: ${error.message}`;
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = "Ask";
  }
}

function refreshPredictions() {
  shipments.forEach((shipment) => {
    Object.keys(shipment.signals).forEach((signal) => {
      const movement = Math.floor(Math.random() * 13) - 6;
      shipment.signals[signal] = Math.max(12, Math.min(92, shipment.signals[signal] + movement));
    });
  });

  updateMetrics();
  renderShipments();
  renderAgentPanel();
  agentAnswer.textContent = "Predictions refreshed with the latest simulated risk signals.";
}

modeFilter.addEventListener("change", renderShipments);
refreshBtn.addEventListener("click", refreshPredictions);
manualShipmentForm.addEventListener("submit", (event) => {
  event.preventDefault();
  addManualShipment();
});

shipmentTabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    switchShipmentTab(tab.dataset.tab);
  });
});

navItems.forEach((item) => {
  item.addEventListener("click", () => {
    handleNavigation(item.dataset.target);
  });
});

agentForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const question = document.querySelector("#agentQuestion").value;
  askAgent(question);
});

updateMetrics();
renderShipments();
renderAgentPanel();
